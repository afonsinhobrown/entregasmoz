import { NextResponse } from 'next/server'
import { readFile, readdir } from 'fs/promises'
import path from 'path'

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const filename = url.searchParams.get('file') || 'entregasmoz.zip'
    
    const downloadPath = path.join(process.cwd(), 'download', filename)
    const file = await readFile(downloadPath)
    
    return new NextResponse(file, {
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': file.length.toString()
      }
    })
  } catch (error) {
    return NextResponse.json({ error: 'File not found' }, { status: 404 })
  }
}
